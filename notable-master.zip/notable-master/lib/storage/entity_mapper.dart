abstract class EntityMapper<E> {
  E toEntity(Map json);

}
